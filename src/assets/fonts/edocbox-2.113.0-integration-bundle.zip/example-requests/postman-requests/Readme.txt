1. Datei "edocbox preview.postman_environment" importieren
2. Im Reiter "Environments" die Umgebung "edocbox preview" auswählen
3. Credentials des technischen Users (username/password) eintragen und ggf. bereits bekannte weitere Variablen
4. Nun die Datei "eDocBox Integration Manual.postman_collection" importieren
5. Es stehen alle im Integration Manual genannten API Request zur Verfügung
6. Request aus der Collection auswählen und absenden -> Fertig!

Achtung!: Beim Absenden der Requests darauf achten, dass die "Umgebung" mit den Variablen ausgewählt ist
(Die Umgebung wird oben rechts angezeigt und kann über das "Auge" bearbeitet werden)
