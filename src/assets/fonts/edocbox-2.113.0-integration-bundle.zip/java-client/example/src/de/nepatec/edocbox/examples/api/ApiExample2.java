package de.nepatec.edocbox.examples.api;


import de.nepatec.edocbox.api.rest.ApiClientException;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.AdHocBusinesscaseResponseType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.AdHocBusinesscaseType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.AdHocPermissionsType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.AttributeDataType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.AttributeType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.AttributeTypeType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.BusinesscaseIdType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.BusinesscaseType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.BusinesscaseTypeExternalShareType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.BusinesscaseTypeFormFieldMappingType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.BusinesscaseTypeType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.CredentialsSelectionType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.DocumentConstraintType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.DocumentExportModeType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.DocumentType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.ExternalBusinesscaseShareAccessType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.ExternalBusinesscaseShareType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.ExternalShareAttributeMappingType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.ExternalShareAttributeType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.IdListType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.IdType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.ModeType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.OwnerType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.ReleaseTypeType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.ShareSecurityType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.ShareStateEnumType;
import de.nepatec.edocbox.api.rest.v2_6.client.dto.SidebarType;
import de.nepatec.edocbox.api.rest.v2_6.client.impl.ApiClientImpl;
import de.nepatec.edocbox.api.rest.v2_6.client.ApiClient;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Example class how to use the API to create, fetch, set states of business cases etc.
 *
 * @author nepatec.de
 */
public class ApiExample2 {

    /**
     * Entry point of the demo application.
     */
    public static void main(String[] args) throws ApiClientException, IOException {

        // 1. configure server access
        //String serverAddress = "preview-edocbox.nepatec.de"; // base server address to access, e.g. edocbox.nepatec.de
        //String serverAddress = "ecluster.nepatec.de";

        String serverAddress = "test-edocbox.nepatec.de/";
        //if server is accessible via a secure connection (https), flag is true. Otherwise, false.
        boolean useSsl = true;

        // username credentials, e.g. youraccount@nepatec.de
        String username = "user@mandant.de"; // username credentials, e.g. youraccount@nepatec.de
        String password = "password"; // your password (user must be granted special rights to access the server)
        
        String email = "your@email.de";
        // your password (user must be granted special rights to access the server)
        String bcTypeId = "mustervorgangId";

        if (serverAddress.equals("<SERVER_ADDRESS>") || username.equals("<USERNAME>") || password.equals("<PASSWORD>")) {
            System.out.println("Please configure the serverAddress/username/password first. Program will exit.");
            System.exit(1);
        }

        ApiClient client = configureClient(serverAddress, useSsl, username, password);

        //1a. Create a businesscase type (once) and reuse later (in 1b) to create actual businesscases.
        //business case type with attributes and form field / external share mapping with example document
        //BusinesscaseTypeType bcType = createBusinessCaseType(client);

        //1b. for the 2nd run re-use the already existing businesscase type template
        //Reference the previously created bc type
        BusinesscaseTypeType bcType = fetchBusinessCaseType(client, bcTypeId);

        // 2. create a business case for the authenticated user
        BusinesscaseType businesscase = createBusinessCase(client, bcType, username);
        //String bcaseId = businesscase.getId();

        //adhoc BC
        BusinesscaseType type = new BusinesscaseType();
        type.setExternalTypeId(bcType.getIdentifier());
        type.setNotifyOwner(false);

        String bcaseId = createAdhocBusinessCase(client, type, email, "forename", "lastname", password);
        System.out.println("Adhoc BC: " + bcaseId);

        // 3. create a mailbox+ share
        List<AttributeType> attributes = new ArrayList<>();

        AttributeType fn = new AttributeType();
        fn.setStringValue("forename");
        attributes.add(fn);

        AttributeType ln = new AttributeType();
        ln.setStringValue("lastname");
        attributes.add(ln);

        AttributeType emailAttr = new AttributeType();
        emailAttr.setStringValue(email);
        attributes.add(emailAttr);

        ExternalBusinesscaseShareAccessType extShareResult = createExternalShare(client, bcaseId, attributes, null);
//
//        System.out.println("Successfully shared business case: " + extShareResult.getPassword() + "  id = " + extShareResult.getId());
//        System.out.println("Click on this link, to open the share: " + extShareResult.getLaunchUrl());

        //System.out.println(businesscase.getDocument().size()+" document(s) found.");

        URL url = client.getLaunchUrlToDocument(businesscase.getDocument().get(0).getId(), ModeType.NORMAL, null, true, SidebarType.NONE, "https://preview-edocbox.nepatec.de", "tvtreeck@nepatec.de", null, null, false, false, null, null);
        System.out.println("Launch URL to document:\n"+url);

//		System.out.println("Businesscase id "+businesscase.getId());
//		URL url2 = client.getLaunchUrlToBusinesscase(businesscase.getId(), null, null, "https://www.edocbox.nepatec.de", username, null , EdocboxModeType.FULL, "true", Boolean.TRUE);
//	    System.out.println("Launch URL to dm:\n"+url2);
//
//	    URL url3 = client.getLaunchUrlToRemoteRecorder(RemoteSignatureMode.SINGLE_RECORD, (String)null, username, null);
//	    System.out.println("Launch URL to remote:\n"+url3);
//	    
//	    URL url4 = client.getUserBindLink(username,null);
//	    System.out.println(url4);

        List<String> types = fetchBusinessCaseTypes(client);

        BusinesscaseType bc = fetchBusinessCase(client, bcaseId);
        System.out.println(bc.getExternalTypeId());

        IdListType shareList = client.listIDsOfExternalSharesOfBusinessCase(bcaseId);

        ExternalBusinesscaseShareType ebcst = client.getExternalShareOfBusinessCase(shareList.getId().get(0), bcaseId);
        System.out.println(ebcst.getState().getState());

        AttributeType vorname = new AttributeType();
//		vorname.setStringValue("Vorname");
//		AttributeType nachname = new AttributeType();
//		nachname.setStringValue("nachname");
//		AttributeType email = new AttributeType();
//		email.setStringValue("tvtreeck@nepatec.de");
//		
//		businesscase.getAttribute().add(vorname);
//		businesscase.getAttribute().add(nachname);
//		businesscase.getAttribute().add(email);

//		for (int i = 0; i < 20; i++) {
//			ExternalBusinesscaseShareAccessType ebsat = createExternalShare(client, businesscase);
//			System.out.println(i+". ShareID: "+ebsat.getId());
//		}
        System.out.println("done... Waiting to finish share: " + extShareResult.getId());

        ExternalBusinesscaseShareType s;
        while (!ShareStateEnumType.COMPLETED.equals((s = client.getExternalShareOfBusinessCase(extShareResult.getId(), bcaseId)).getState().getState())) {
            System.out.println("Share not completed, waiting for completion and user input... State=" + s.getState().getState());
            Scanner scanner = new Scanner(System.in);
            String line = scanner.nextLine();
        }

        System.out.println("Deleting share " + s.getId() + " ...");
        client.deleteExternalShareOfBusinessCase(s.getId(), bcaseId);
        System.out.println("Deleting share... DONE");
        System.out.println("Deleting bcase " + bcaseId + "... ");
        client.deleteBusinessCase(bcaseId, true);
        System.out.println("Deleting bcase " + bcaseId + "... DONE");

        System.out.println("Test done...");
    }

    /**
     * Configures the credentials to access the server.
     *
     * @param serverAddress base server address to access
     * @param useSsl if server is accessible via a secure connection (https), flag is true. Otherwise, false.
     * @param username username credentials
     * @param password password credentials (user must be granted special rights to access the server)
     */
    private static ApiClient configureClient(String serverAddress, boolean useSsl, String username, String password) {
        ApiClientImpl client = new ApiClientImpl();

        client.setServerAddress(serverAddress);
        client.setUser(username);
        client.setPassword(password);
        client.setSslEnabled(useSsl);
        client.setConnectionTimeoutMillis(30000);
        client.setReadTimeoutMillis(30000);
        return client;
    }

    private static BusinesscaseTypeType createBusinessCaseType(ApiClient client)
        throws IOException, ApiClientException {
        BusinesscaseTypeType bcaseToAdd = new BusinesscaseTypeType();

        bcaseToAdd.setDisplayName("Kampagnen Beispiel");
        bcaseToAdd.setIdentifier("totallyNewCampaignTyp");
        bcaseToAdd.setIcon(toByteArray(ClassLoader.getSystemResourceAsStream("bcasetypeicon.png")));

        // load document
        DocumentType documentType = new DocumentType();
        documentType.setFileData(toByteArray(ClassLoader.getSystemResourceAsStream("3Attributes1Signature.pdf")));
        documentType.setExternalId("document");
        documentType.setRefId("document");
        documentType.setFileName("exampleDocument.pdf");
        documentType.setRequired(true);

        bcaseToAdd.getDocument().add(documentType);

        // add attributes to business case type
        AttributeTypeType forenameAttributeType = createBusinessCaseTypeAttributeType("forename", "Vorname",
            AttributeDataType.TEXT);
        AttributeTypeType nameAttributeType = createBusinessCaseTypeAttributeType("name", "Nachname",
            AttributeDataType.TEXT);
        AttributeTypeType mailAttributeType = createBusinessCaseTypeAttributeType("mail", "E-Mail",
            AttributeDataType.EMAIL);

        bcaseToAdd.getAttribute().add(forenameAttributeType);
        bcaseToAdd.getAttribute().add(nameAttributeType);
        bcaseToAdd.getAttribute().add(mailAttributeType);

        // add attribute mapping to document
        bcaseToAdd.getFormFieldMapping()
            .add(createFormFieldMappingType(documentType, forenameAttributeType, "FORMFIELD1"));
        bcaseToAdd.getFormFieldMapping().add(createFormFieldMappingType(documentType, nameAttributeType, "FORMFIELD2"));
        bcaseToAdd.getFormFieldMapping().add(createFormFieldMappingType(documentType, mailAttributeType, "FORMFIELD3"));

        // add attribute mapping to external share
        BusinesscaseTypeExternalShareType externalShare = new BusinesscaseTypeExternalShareType();
        externalShare.setReleaseType(ReleaseTypeType.EDIT_AND_SIGN);
        externalShare.setExternalShareEnabled(true);
        externalShare.getAttributeMapping()
            .add(createExternalShareAttributeMappingType(forenameAttributeType, ExternalShareAttributeType.FORENAME));
        externalShare.getAttributeMapping()
            .add(createExternalShareAttributeMappingType(nameAttributeType, ExternalShareAttributeType.SURNAME));
        externalShare.getAttributeMapping()
            .add(createExternalShareAttributeMappingType(mailAttributeType, ExternalShareAttributeType.EMAIL));
        bcaseToAdd.setExternalShare(externalShare);

        IdType bcaseTypeId = client.addBusinesscaseType(bcaseToAdd);
        System.out.println("Successfully created Businesscasetype with id " + bcaseTypeId.getId());

        return client.getBusinessCaseType(bcaseTypeId.getId());
    }

    /**
     * Creates a business case for the owner with the specified loginId.
     *
     * The method assumes that the user credentials are correct and user is allowed to access a "predefined"
     * business case type "ANTRAG", having three attributes: "FORNAME", "NAME", "BIRTH".
     * For a different business case type, its attributes must be known.
     *
     * @param client stub used to access the server side
     * @param businesscaseTypeId the id of the businesscase to be referenced
     * @param ownerLoginId loginId of the owner of the business case that is created
     */
    private static BusinesscaseType createBusinessCase(ApiClient client, String businesscaseTypeId,
        String ownerLoginId) throws ApiClientException {
        BusinesscaseType businessCase = new BusinesscaseType();

        businessCase.setName("A Business Case Example");
        businessCase.setExternalId("bcaseExample");
        businessCase.setExternalTypeId(businesscaseTypeId);

        businessCase.getAttribute().add(createBusinessCaseAttribute("forename", "Max"));
        businessCase.getAttribute().add(createBusinessCaseAttribute("name", "Mustermann"));
        businessCase.getAttribute().add(createBusinessCaseAttribute("mail", "max.mustermann@nepatec.de"));

        OwnerType owner = new OwnerType();
        owner.setLoginId(ownerLoginId);
        businessCase.setOwner(owner);
        businessCase.setNotifyOwner(false);

        BusinesscaseIdType id = client.addBusinessCase(businessCase);

        return client.getBusinessCase(id.getId(), DocumentExportModeType.ORIGINAL, false, false);
    }

    /**
     * Creates an adhoc BC and returns its ID.
     */
    private static String createAdhocBusinessCase(ApiClient client, BusinesscaseType businesscaseType,
        String email, String forename, String lastname, String pazzword) throws ApiClientException {
        AdHocBusinesscaseType businessCase = new AdHocBusinesscaseType();
        if (businesscaseType != null) {
            businessCase.setBusinesscase(businesscaseType);
        }

        CredentialsSelectionType creds = new CredentialsSelectionType();
        creds.setEmailAddress(email);
        creds.setForename(forename);
        creds.setLastname(lastname);
        creds.setPassword(pazzword);
        businessCase.setCredentials(creds);

        AdHocPermissionsType perms = new AdHocPermissionsType();
        perms.setHome(true);
        perms.setDocuments(true);
        perms.setAPIUser(true);
        businessCase.setPermissions(perms);

        AdHocBusinesscaseResponseType response = client.addAdHocBusinesscase(businessCase);

        return response.getId();
    }


    /**
     * Creates a business case for the owner with the specified loginId.
     *
     * The method assumes that the user credentials are correct and user is allowed to access a "predefined"
     * business case type "ANTRAG", having three attributes: "FORNAME", "NAME", "BIRTH".
     * For a different business case type, its attributes must be known.
     *
     * @param client stub used to access the server side
     * @param businesscaseType The businesscasetype which should be referenced
     * @param ownerLoginId loginId of the owner of the business case that is created
     */
    private static BusinesscaseType createBusinessCase(ApiClient client, BusinesscaseTypeType businesscaseType,
        String ownerLoginId) throws ApiClientException {
        return createBusinessCase(client, businesscaseType.getIdentifier(), ownerLoginId);
    }

    /**
     * Creates an external Share
     */
    private static ExternalBusinesscaseShareAccessType createExternalShare(ApiClient client, String bcaseId,
        List<AttributeType> attributes, List<DocumentType> documents) throws ApiClientException {

        ExternalBusinesscaseShareType shareType = new ExternalBusinesscaseShareType();
        shareType.setInfoText("Hallo, bitte unterschreiben Sie die Dokumente!");

        if (attributes != null && !attributes.isEmpty()) {
            shareType.setForename(attributes.get(0).getStringValue());
            shareType.setLastname(attributes.get(1).getStringValue());
            shareType.setEmailAddress(attributes.get(2).getStringValue());
        }
        shareType.setNotify(false);
        shareType.setMailDocumentsAfterComplete(false);
        shareType.setMailDocumentsAfterBusinessCaseComplete(false);
        shareType.setMailText("Should not be sent!");

        //for SMS sending
        //shareType.setPhoneNumber("");
        //shareType.setSecurityDelivery(SecurityDeliveryType.SMS);
        shareType.setAccessProtection(ShareSecurityType.TOKEN);

        XMLGregorianCalendar xmlGregCal;
        try {
            GregorianCalendar c = (GregorianCalendar) Calendar.getInstance();
            c.add(Calendar.DATE, 14);
            xmlGregCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
            shareType.setEnd(xmlGregCal);
        } catch (DatatypeConfigurationException e) {
            throw new ApiClientException("Error creating end date: " + e.getMessage(), e);
        }

//		SignatureConstraintType mandatorySignature = new SignatureConstraintType();
//		mandatorySignature.setId("SIGNATUR1");
//		mandatorySignature.setType(SignatureConstraintTypeType.MANDATORY);

        if (documents != null && !documents.isEmpty()) {
            DocumentConstraintType documentConstraintType = new DocumentConstraintType();
            documentConstraintType.setId(documents.get(0).getId());
            //documentConstraintType.getSignatureConstraint().add(mandatorySignature);
            documentConstraintType.setEditNonSignFieldsAllowed(true);
            documentConstraintType.setVisible(true);
            shareType.getDocumentConstraint().add(documentConstraintType);
        }

        return client.shareBusinessCaseExternally(bcaseId, shareType);
    }

    private static AttributeTypeType createBusinessCaseTypeAttributeType(String externalId, String displayName,
        AttributeDataType dataType) {
        AttributeTypeType attributeTypeType = new AttributeTypeType();
        attributeTypeType.setExternalId(externalId);
        attributeTypeType.setDisplayName(displayName);
        attributeTypeType.setDataType(dataType);
        attributeTypeType.setMandatory(true);
        attributeTypeType.setRefId(externalId);

        return attributeTypeType;
    }

    private static ExternalShareAttributeMappingType createExternalShareAttributeMappingType(
        AttributeTypeType attributeRef, ExternalShareAttributeType attributeType) {
        ExternalShareAttributeMappingType externalShareAttributeMappingType = new ExternalShareAttributeMappingType();
        externalShareAttributeMappingType.setAttributeType(attributeRef);
        externalShareAttributeMappingType.setExternalShareAttribute(attributeType);

        return externalShareAttributeMappingType;
    }

    private static BusinesscaseTypeFormFieldMappingType createFormFieldMappingType(DocumentType documentRef,
        AttributeTypeType attributeRef, String formFieldName) {
        BusinesscaseTypeFormFieldMappingType formFieldMappingType = new BusinesscaseTypeFormFieldMappingType();
        formFieldMappingType.setDocument(documentRef);
        formFieldMappingType.setAttributeType(attributeRef);
        formFieldMappingType.setFormFieldName(formFieldName);

        return formFieldMappingType;
    }

    /**
     * Builds an attribute with the specified id and value.
     */
    private static AttributeType createBusinessCaseAttribute(String externalId, String stringValue) {
        AttributeType attr = new AttributeType();
        attr.setExternalId(externalId);
        attr.setStringValue(stringValue);

        return attr;
    }

    /**
     * Sets the business case state to completed.
     */
    private static void setStateToCompleted(ApiClient client, String id) throws ApiClientException {
        client.setStateCompleted(id, false);

        System.out.println("Business case '" + id + "' completed.");
    }

    /**
     * Fetches all business case type ids.
     */
    private static List<String> fetchBusinessCaseTypes(ApiClient client) throws ApiClientException {
        IdListType businessCaseTypes = client.listBusinessCaseTypes();

        System.out.println("The following ids have been found '" + businessCaseTypes.getId());

        return businessCaseTypes.getId();
    }

    /**
     * Fetches a businesscase type.
     */
    private static BusinesscaseTypeType fetchBusinessCaseType(ApiClient client, String id) throws ApiClientException {
        BusinesscaseTypeType businessCaseType = client.getBusinessCaseType(id);

        System.out.println("The following businesscasetype has been found: '" + businessCaseType.getDisplayName() + "'");

        return businessCaseType;
    }

    /**
     * Fetches the business case with the specified id.
     */
    private static BusinesscaseType fetchBusinessCase(ApiClient client, String id) throws ApiClientException {
        boolean withFileData = false;
        boolean includeHistory = false;

        BusinesscaseType businessCase = client.getBusinessCase(id, DocumentExportModeType.EXCLUDE_BIOMETRY, withFileData, includeHistory);

        System.out.println("Business case '" + id + "' fetched.");

        return businessCase;
    }

    /**
     * Sets the business case state to acknowledged.
     */
    private static void setStateToAcknowledged(ApiClient client, String id) throws ApiClientException {
        client.setStateExternalTransferred(id);

        System.out.println("Business case '" + id + "' acknowledged.");
    }

    private static byte[] toByteArray(InputStream in) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();

        int nRead;
        byte[] data = new byte[8192];

        while ((nRead = in.read(data, 0, data.length)) != -1) {
            buffer.write(data, 0, nRead);
        }

        buffer.flush();

        return buffer.toByteArray();
    }
}
