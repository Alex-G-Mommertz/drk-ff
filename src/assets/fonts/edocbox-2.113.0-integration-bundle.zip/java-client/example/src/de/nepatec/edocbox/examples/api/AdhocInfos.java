package de.nepatec.edocbox.examples.api;

public class AdhocInfos {
    
    private String buinsesscaseId;
    private String adhocUserLogin;
    private String adhocUserPassword;
    public String getBuinsesscaseId() {
        return this.buinsesscaseId;
    }
    public void setBuinsesscaseId(String buinsesscaseId) {
        this.buinsesscaseId = buinsesscaseId;
    }
    public String getAdhocUserLogin() {
        return this.adhocUserLogin;
    }
    public void setAdhocUserLogin(String adhocUserLogin) {
        this.adhocUserLogin = adhocUserLogin;
    }
    public String getAdhocUserPassword() {
        return this.adhocUserPassword;
    }
    public void setAdhocUserPassword(String adhocUserPassword) {
        this.adhocUserPassword = adhocUserPassword;
    }
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("AdhocInfos [");
        if (this.buinsesscaseId != null) {
            builder.append("buinsesscaseId=");
            builder.append(this.buinsesscaseId);
            builder.append(", ");
        }
        if (this.adhocUserLogin != null) {
            builder.append("adhocUserLogin=");
            builder.append(this.adhocUserLogin);
            builder.append(", ");
        }
        if (this.adhocUserPassword != null) {
            builder.append("adhocUserPassword=");
            builder.append(this.adhocUserPassword);
        }
        builder.append("]");
        return builder.toString();
    }  
}
